import React from 'react';

export default function Menu() {
  return <h3>test</h3>;
}
